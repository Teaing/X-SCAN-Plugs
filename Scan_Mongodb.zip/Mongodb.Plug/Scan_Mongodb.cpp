#include "C:\\mongo-cxx-driver-legacy\\src\\mongo\\client\\dbclient.h"
#include <winsock2.h> 

#ifdef __cplusplus
    extern "C" {
#endif // __cplusplus

#include "..\\XScanLib\\XScanLib.h"

#ifdef __cplusplus
    }
#endif // __cplusplus

extern "C" __declspec(dllexport) BOOL __stdcall GetPluginInfo(PLUGIN_INFO *);
extern "C" __declspec(dllexport) BOOL __stdcall PluginFunc (VOID *);
extern "C" DWORD WINAPI ScanMongodb (VOID *);
extern "C" DWORD WINAPI CheckPort ( char *Host, int Port );

#pragma comment(lib, "Dbghelp.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "..\\XScanLib\\XScanLib.lib")
#pragma comment(lib, "C:\\mongo-cxx-driver-legacy\\build\\win32\\dynamic-windows\\use-system-boost\\mongoclient.lib")

#define	VULN_MEMBER_NAME	"Mongodbδ��Ȩ����"
#define	CHECKING_STRING		"���ڼ��Mongodb�Ƿ����δ��Ȩ���ʰ�ȫ����"
#define VERSION				"0.1"
#define	CMD_PARMAS			"-mongodb"
#define	PROMPT				"-mongodb    :���Mongodbδ��Ȩ����"
#define	AUTHOR				"Tea"
#define	DESCRIPTION			"�ò��ֻ��Mongodb����δ��Ȩ���ʼ�⡣"
#define	TIMEOUT				10000
#define	ICON				"sql.bmp"
#define FILENAME            "Scan_Mongodb.xpn"

#define	Mongodb_PORT		27017


BOOL APIENTRY DLLMain(HANDLE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	return TRUE;
}

BOOL __stdcall GetPluginInfo (PLUGIN_INFO *Info)
{
	// ���ò����Ϣ
	strcpy_s( Info->szClassName, VULN_MEMBER_NAME );
	strcpy_s( Info->szMemberName, VULN_MEMBER_NAME );
	strcpy_s( Info->szVersion, VERSION );
	strcpy_s( Info->szFileName, FILENAME );
	strcpy_s( Info->szParamsRequest, CMD_PARMAS );
	strcpy_s( Info->szPrompt, PROMPT );
	Info->nSingle = 1;
	strcpy_s( Info->szAuthorName, AUTHOR );
	strcpy_s( Info->szDescription, DESCRIPTION );
	Info->dwTimeOut = TIMEOUT;
	Info->nMark = 1;
	strcpy_s( Info->szImageFile, ICON );

	return TRUE;
}

BOOL __stdcall PluginFunc( VOID *Parm )
{
	int VulnNumber = 0;

	if( !PlugInitLib((struct arglist *)Parm) )
	{
		return FALSE;
	}

	PlugSetVulnNum( (struct arglist *)Parm, 0 );

	PlugSetCurrentSchedule( (struct arglist *)Parm, CHECKING_STRING );

	// ���뵽�̳߳�
	PlugAddThread( (struct arglist *)Parm, ScanMongodb, Parm, TIMEOUT );

	PlugWaitThread( (struct arglist *)Parm );

	VulnNumber = PlugGetVulnNum( (struct arglist *)Parm );

	return VulnNumber > 0 ? TRUE : FALSE;
}

using namespace std;
using namespace mongo;

DWORD WINAPI ScanMongodb( void * Parm )
{
	char	Host[256] = { 0 };
	char	LogType[8] = { 0 };
	int		Verbose = 0;
	char	Message[128] = { 0 };
	int		PortState = -1;
	string		errmsg;

	DBClientConnection conn( false , NULL , 6 );

	struct arglist	*MyArgList = (struct arglist *)Parm;

	// ��ȡɨ�����
	strncpy_s( Host, (char *)PlugGetParams(MyArgList, "HostName"), 255 );
	strncpy_s( LogType, (char *)PlugGetParams(MyArgList, "LogType"), 7 );
	Verbose = (int)PlugGetParams(MyArgList, "ShowVerbose");

	PlugSetCurrentSchedule( MyArgList, CHECKING_STRING );
	
	PortState = CheckPort( Host, Mongodb_PORT );

	// �˿�û����
	if( PortState <= 0 )
	{
		return 0;
	}

	if( !Verbose )
	{
		PlugAlertUser ( MyArgList, AT_NORMAL, CHECKING_STRING );
	}

	try {
		if (conn.connect(Host, errmsg ) ) 
		{
			list<string> Result_Tmp = conn.getDatabaseNames();
			if (!Result_Tmp.empty())
			{
				sprintf_s( Message, "Mongodb����δ��Ȩ����©��!");
				PlugAlertUser( MyArgList, AT_WARNING, Message );
				memset( Message, 0, sizeof(Message) );
				sprintf_s( Message, "Mongodb����δ��Ȩ����©��!\n���Mongodbʹ����֤!");
				PlugLogToFile( MyArgList, "27017/TCP", "HOLE", Message );
				PlugAddVulnNum( MyArgList );
				memset( Message, 0, sizeof(Message) );
				sprintf_s ( Message, "%s\n%s\n", Host, VULN_MEMBER_NAME);
				PlugAddToTV ( Message, ICON );
			}
		}
	}
	catch (exception& e ) 
	{
	}
	errmsg.clear();
	return 0;
}

DWORD WINAPI CheckPort ( char *Host, int Port)
{
	SOCKET		sock;
	SOCKADDR_IN	sin;

	memset( &sin, 0, sizeof(SOCKADDR_IN) );

	sin.sin_family = AF_INET;
	sin.sin_port = htons( Port );

	if( inet_addr( Host ) != INADDR_NONE )
	{
		sin.sin_addr.s_addr = inet_addr( Host );
	}		
	else
	{
		struct hostent	*phost = gethostbyname( Host );

		if( phost == NULL )
		{
			return -1;
		}
		memcpy( &sin.sin_addr , phost->h_addr_list[0] , phost->h_length );
	}

	// ����socketʧ���򷵻ض˿ڿ��ţ��ȴ�Mongodb apiֱ�����ӣ�����©��
	sock = socket( AF_INET, SOCK_STREAM, 0 );
	if( sock == INVALID_SOCKET )
	{
		return 1;
	}

	 int state = connect( sock , (struct sockaddr *)&sin , sizeof(sin) );
	 if( state == SOCKET_ERROR )
	 {
		 return -1;
	 }
	 else
	 {
		 return 1;
	 }
}
